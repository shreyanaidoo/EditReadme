using Microsoft.AspNetCore.Mvc;
using ST10195567_PROG6212_Part2.Models;
using System.Diagnostics;

namespace ST10195567_PROG6212_Part2.Controllers
{
    public class HomeController : Controller
    {
        
        
            // Action for rendering the Home Page (GET)
            public ActionResult Index()
            {
                return View();
            }

            // These actions will simply redirect to the appropriate pages

            public ActionResult SubmitClaim()
            {
                return RedirectToAction("SubmitClaim", "Claims");
            }

            public ActionResult ViewClaim()
            {
                return RedirectToAction("ViewClaim", "Claims");
            }

            public ActionResult UploadDocuments()
            {
                return RedirectToAction("UploadDocuments", "Claims");
            }

            public ActionResult ApproveClaim()
            {
                return RedirectToAction("PendingClaims", "Claims");
            }

            public ActionResult TrackClaimStatus()
            {
                return RedirectToAction("TrackClaimStatus", "Claims");
            }
        }
    }

