﻿using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using ST10195567_PROG6212_Part2.Models;

namespace ST10195567_PROG6212_Part2.Controllers
{
    public class ClaimsController : Controller
    {
        private static List<ClaimModel> claimsList = new List<ClaimModel>();

        private readonly IWebHostEnvironment _environment;

        public ClaimsController(IWebHostEnvironment environment)
        {
            _environment = environment;
        }

        // GET: Claims/ViewClaims
        public IActionResult ViewClaim(int claimId)
        {
            // Find the claim by ID
            var claim = claimsList.FirstOrDefault(c => c.ClaimId == claimId);

            if (claim == null)
            {
                return NotFound(); // If no claim found, return a 404 page
            }

            return View(claim); // Pass the claim model to the view
        }

        // POST: Claims/SubmitClaim
        [HttpPost]
        public IActionResult SubmitClaim(ClaimModel model, IFormFile supportingDocument)
        {
            if (ModelState.IsValid)
            {
                // Generate a unique ClaimId
                model.ClaimId = claimsList.Count > 0 ? claimsList.Max(c => c.ClaimId) + 1 : 1;

                // Handle file upload if provided
                if (supportingDocument != null && supportingDocument.Length > 0)
                {
                    string uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads");
                    Directory.CreateDirectory(uploadsFolder); // Ensure directory exists

                    string uniqueFileName = Guid.NewGuid().ToString() + "_" + supportingDocument.FileName;
                    string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        supportingDocument.CopyTo(fileStream);
                    }

                    // Save the file path to the claim model
                    model.SupportingDocument = uniqueFileName;
                }

                // Calculate the total amount
                model.TotalAmount = model.HoursWorked * model.HourlyRate;

                // Add the claim to the in-memory list
                claimsList.Add(model);

                // Redirect to ViewClaims to see the submitted claim
                return RedirectToAction("ViewClaim");
            }

            return View(model); // If model state is invalid, return the form
        }

        public IActionResult ApproveClaim(int claimId)
        {
            // Find the claim by ID
            var claim = claimsList.FirstOrDefault(c => c.ClaimId == claimId);

            if (claim == null)
            {
                return NotFound(); // If no claim found, return a 404 page
            }

            return View(claim); // Pass the claim model to the view
        }

        // POST: Claims/ProcessApproval
        [HttpPost]
        public IActionResult ProcessApproval(int claimId, string actionType)
        {
            // Find the claim by ID
            var claim = claimsList.FirstOrDefault(c => c.ClaimId == claimId);

            if (claim == null)
            {
                return NotFound();
            }

            // Update claim status based on action
            if (actionType == "Approve")
            {
                claim.Status = "Approved";
            }
            else if (actionType == "Decline")
            {
                claim.Status = "Declined";
            }

            // Redirect to ViewClaims to show updated claim status
            return RedirectToAction("ViewClaims");
        }

        public IActionResult SupportingDocument()
        {
            return View();
        }

        public IActionResult ApproveClaims()
        {
            return View();
        }

        public IActionResult ClaimHistory()
        {
            return View();
        }
    }
}
