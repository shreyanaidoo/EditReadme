﻿namespace ST10195567_PROG6212_Part2.Models
{
    public class ClaimModel
    {
        public int ClaimId { get; set; }
        public int LecturerId { get; set; }
        public int LecturerName { get; set; }
       
        // Unique ID for each claim
        public DateTime StartDate { get; set; }
        public int HoursWorked { get; set; }
        public decimal HourlyRate { get; set; }
        public decimal TotalAmount { get; set; }
        public string Description { get; set; }
        public string SupportingDocument
        { get; set; }
        public string Status { get; set; }
    }
}
